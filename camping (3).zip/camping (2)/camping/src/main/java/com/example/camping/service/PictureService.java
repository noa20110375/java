package com.example.camping.service;

import org.springframework.stereotype.Service;

@Service
public class PictureService {

}
