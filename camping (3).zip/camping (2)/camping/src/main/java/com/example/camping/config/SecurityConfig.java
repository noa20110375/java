package com.example.camping.config;

import javax.servlet.Filter;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.camping.jwt.CustomAuthenticationEntryPoint;
import com.example.camping.jwt.JwtRequestFilter;

import lombok.AllArgsConstructor;




@Configuration
@EnableWebSecurity
@AllArgsConstructor
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
   

	private Filter corsFilter;
	
	

	@Bean public BCryptPasswordEncoder encodePwd() {
		return new BCryptPasswordEncoder();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.csrf().disable()
	
       
        .httpBasic().disable()
        .formLogin().disable()
        .addFilter(corsFilter);
		
		http.authorizeRequests()
		
		  .antMatchers("/user").authenticated()
		 
		  .anyRequest()
		  
		  .permitAll()
		  .and()
	
		   .formLogin()
		 
		   .loginPage("/login")
		   
		   .defaultSuccessUrl("/")
		 .and()
		    .logout()
		    .logoutUrl("/logout")
		    .logoutSuccessUrl("/")
		    .invalidateHttpSession(true);
		http.csrf().disable();
		http.authorizeRequests()
		 .and()
        
         .exceptionHandling()
         .authenticationEntryPoint(new CustomAuthenticationEntryPoint());


 http.addFilterBefore(new JwtRequestFilter(), UsernamePasswordAuthenticationFilter.class);
		
		  
		
	}
	
}
