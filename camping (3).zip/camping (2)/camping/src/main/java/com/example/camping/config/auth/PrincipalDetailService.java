package com.example.camping.config.auth;

import com.example.camping.model.Member;
import com.example.camping.model.User;

public class PrincipalDetailService {

	
	
	
	public PrincipalDetailService(Member member) {
	 
 }
	
	public PrincipalDetailService(User user) {
		 
	 }
}
